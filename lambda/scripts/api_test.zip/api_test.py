import json

def lambda_handler(event, context):
    user_list = ["Sanu", "Peter"]
    response = user_list
    return response
    